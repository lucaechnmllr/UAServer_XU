
#ifndef _XU_NodeManagerXUNamespace_H__
#define _XU_NodeManagerXUNamespace_H__

#pragma warning(push,0)
#include "uamutex.h"
#include "uabasenodes.h"
#include "nodemanagerbase.h"
#include "uaobjecttypes.h"
#include "opcua_foldertype.h"
#pragma warning(pop)

#include "xu_identifiers.h"
#include "xu_xuobjecttype.h"
#include "xu_floatpduobjecttype.h"
#include "xu_intpduobjecttype.h"
#include <unordered_map>
#include <vector>
#include <string>


/** Namespace for the UA information model http://yourorganisation.org/UAServer/
*/
namespace XU {

    /** Base class for NodeManager for XUNamespace information model.
     *
     *  This class is used to create the nodes defined for the namespace http://yourorganisation.org/UAServer/.
     *
     */
    class NodeManagerXUNamespace : public NodeManagerBase, public UaThread
    {
        NodeManagerXUNamespace();
    public:
        /* construction / destruction */
        NodeManagerXUNamespace(OpcUa_Boolean firesEvents, OpcUa_Int32 nHashTableSize = 10000019);
        virtual ~NodeManagerXUNamespace() {};

        //- Interface NodeManagerUaNode -------------------------------------------------------
        virtual UaStatus   afterStartUp();
        virtual UaStatus   beforeShutDown();
        //virtual XmlUaNodeFactoryNamespace* getUaNodeFactory(OpcUa_UInt16 namespaceIndex) const;
        //- Interface NodeManagerUaNode -------------------------------------------------------

        //- Interface UaThread
        void run();
        //- Interface UaThread

        
        static OpcUa_UInt16 getTypeNamespace();

        static void setServerMode(OpcUa_UInt16 mode);
        static OpcUa_UInt16 getServerMode() { return s_server_mode; }

        //- Read the write Permisson file
        //- Safe KKS of write permitted files to vector m_pWrite_perm_list
        void readWritePermissionFile();
        


    private:
        UaStatus createDataTypeNodes();
        UaStatus createReferenceTypeNodes();
        UaStatus addAdditionalHierarchicalReferences();
        UaStatus addAdditionalNonHierarchicalReferences();

        bool m_stopThread;
        bool m_signalimage_complete;

        //! Defines the server mode 
        //! 0: Normal Mode (writing values will not be forced with '!')
        //! 1: Rapid Mode (writing values will be forced with '!')
        static OpcUa_UInt16 s_server_mode;

        XU::XUObjectType* xu_object_ref;
        std::vector<std::string> m_pWrite_perm_list;


        //std::unordered_map<std::string, IntPDUObjectType*> object_list_int; //List of all "IntPDU" objects
        //std::unordered_map<std::string, FloatPDUObjectType*> object_list_float; //List of all "FloatPDU" objects
        //std::unordered_map<std::string, OpcUa::FolderType*> folder_list; //List of all Folders


    protected:
        UaMutex             m_mutex;
        static OpcUa_UInt16 s_namespaceIndex;
        
        


        
        
#if SUPPORT_Event_Subscription_Server_Facet
        UaStatus recursiveRegisterEventSources(const UaNodeId& startingNode, std::set<UaNodeId>& setBrowsedNodes);
#endif // SUPPORT_Event_Subscription_Server_Facet
    };

} // End namespace for the UA information model http://yourorganisation.org/XU_Test_ServerConfig/

#endif // #ifndef __NodeManagerXUNamespace_H__